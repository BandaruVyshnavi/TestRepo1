#!/bin/bash
chmod -R 777 /var/www/html